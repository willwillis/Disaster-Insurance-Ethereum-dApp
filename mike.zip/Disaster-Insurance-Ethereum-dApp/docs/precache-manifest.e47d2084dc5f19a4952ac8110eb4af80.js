self.__precacheManifest = [
  {
    "revision": "54875c93e10f1a06de68",
    "url": "/static/css/main.655b1ab1.chunk.css"
  },
  {
    "revision": "54875c93e10f1a06de68",
    "url": "/static/js/main.54875c93.chunk.js"
  },
  {
    "revision": "93ea7b44a3006f8fa25d",
    "url": "/static/css/1.68d231d9.chunk.css"
  },
  {
    "revision": "93ea7b44a3006f8fa25d",
    "url": "/static/js/1.93ea7b44.chunk.js"
  },
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "fb58eec7684671fa24e750fbdb293f9d",
    "url": "/index.html"
  }
];
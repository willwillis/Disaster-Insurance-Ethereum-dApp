/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onUpdateSensor = `subscription OnUpdateSensor($id: ID!) {
  onUpdateSensor(id: $id) {
    id
    temp
    smoke
    lat
    long
    timestamp
  }
}
`;

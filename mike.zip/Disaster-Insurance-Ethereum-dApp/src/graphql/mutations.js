/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createSensor = `mutation CreateSensor($input: CreateSensorInput!) {
  createSensor(input: $input) {
    id
    temp
    smoke
    lat
    long
    timestamp
  }
}
`;
export const updateSensor = `mutation UpdateSensor($input: UpdateSensorInput!) {
  updateSensor(input: $input) {
    id
    temp
    smoke
    lat
    long
    timestamp
  }
}
`;
export const deleteSensor = `mutation DeleteSensor($input: DeleteSensorInput!) {
  deleteSensor(input: $input) {
    id
    temp
    smoke
    lat
    long
    timestamp
  }
}
`;
